This is an extension that creates links using common prefixes:

@handle: twitter.com/handle
/r/subreddit or r/subreddit: reddit.com/r/subreddit
/u/user or u/user: reddit.com/u/user

Written by Andrew Hanrahan (github.com/Adoggman, http://hanrahan.co)

Source can be found at github.com/Adoggman/AutoLinker
Inspired by github.com/Posnet/xkcd-substitutions